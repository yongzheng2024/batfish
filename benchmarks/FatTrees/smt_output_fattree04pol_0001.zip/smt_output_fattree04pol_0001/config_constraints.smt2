(declare-fun Config_edge-15_CommunityList_list1__Line1__exact_community_2_2_action
             ()
             Bool)
(declare-fun Config_edge-15_CommunityList_list1__Line1__exact_community_2_2_2_2_community
             ()
             Bool)
(declare-fun Config_edge-15_CommunityList_list2__Line1__exact_community_5_2_action
             ()
             Bool)
(declare-fun Config_edge-15_CommunityList_list2__Line1__exact_community_5_2_5_2_community
             ()
             Bool)
(declare-fun Config_edge-15_RoutingPolicy_route_out__Line3__set_community_5_2_community
             ()
             Bool)
(declare-fun Config_edge-15_RoutingPolicy_route_out__Line4__set_community_2_2_community
             ()
             Bool)
(declare-fun Config_core-1_CommunityList_list1__Line1__exact_community_3_0_action
             ()
             Bool)
(declare-fun Config_core-1_CommunityList_list1__Line1__exact_community_3_0_3_0_community
             ()
             Bool)
(declare-fun Config_core-1_CommunityList_list2__Line1__exact_community_6_0_action
             ()
             Bool)
(declare-fun Config_core-1_CommunityList_list2__Line1__exact_community_6_0_6_0_community
             ()
             Bool)
(declare-fun Config_core-1_RoutingPolicy_route_out__Line3__set_community_6_0_community
             ()
             Bool)
(declare-fun Config_core-1_RoutingPolicy_route_out__Line4__set_community_3_0_community
             ()
             Bool)
(declare-fun Config_core-0_CommunityList_list1__Line1__exact_community_3_0_action
             ()
             Bool)
(declare-fun Config_core-0_CommunityList_list1__Line1__exact_community_3_0_3_0_community
             ()
             Bool)
(declare-fun Config_core-0_CommunityList_list2__Line1__exact_community_6_0_action
             ()
             Bool)
(declare-fun Config_core-0_CommunityList_list2__Line1__exact_community_6_0_6_0_community
             ()
             Bool)
(declare-fun Config_core-0_RoutingPolicy_route_out__Line3__set_community_6_0_community
             ()
             Bool)
(declare-fun Config_core-0_RoutingPolicy_route_out__Line4__set_community_3_0_community
             ()
             Bool)
(declare-fun Config_edge-18_CommunityList_list1__Line1__exact_community_2_3_action
             ()
             Bool)
(declare-fun Config_edge-18_CommunityList_list1__Line1__exact_community_2_3_2_3_community
             ()
             Bool)
(declare-fun Config_edge-18_CommunityList_list2__Line1__exact_community_5_3_action
             ()
             Bool)
(declare-fun Config_edge-18_CommunityList_list2__Line1__exact_community_5_3_5_3_community
             ()
             Bool)
(declare-fun Config_edge-18_RoutingPolicy_route_out__Line3__set_community_5_3_community
             ()
             Bool)
(declare-fun Config_edge-18_RoutingPolicy_route_out__Line4__set_community_2_3_community
             ()
             Bool)
(declare-fun Config_aggregation-17_CommunityList_list1__Line1__exact_community_1_3_action
             ()
             Bool)
(declare-fun Config_aggregation-17_CommunityList_list1__Line1__exact_community_1_3_1_3_community
             ()
             Bool)
(declare-fun Config_aggregation-17_CommunityList_list2__Line1__exact_community_4_3_action
             ()
             Bool)
(declare-fun Config_aggregation-17_CommunityList_list2__Line1__exact_community_4_3_4_3_community
             ()
             Bool)
(declare-fun Config_aggregation-17_RoutingPolicy_route_out__Line3__set_community_4_3_community
             ()
             Bool)
(declare-fun Config_aggregation-17_RoutingPolicy_route_out__Line4__set_community_1_3_community
             ()
             Bool)
(declare-fun Config_core-3_CommunityList_list1__Line1__exact_community_3_0_action
             ()
             Bool)
(declare-fun Config_core-3_CommunityList_list1__Line1__exact_community_3_0_3_0_community
             ()
             Bool)
(declare-fun Config_core-3_CommunityList_list2__Line1__exact_community_6_0_action
             ()
             Bool)
(declare-fun Config_core-3_CommunityList_list2__Line1__exact_community_6_0_6_0_community
             ()
             Bool)
(declare-fun Config_core-3_RoutingPolicy_route_out__Line3__set_community_6_0_community
             ()
             Bool)
(declare-fun Config_core-3_RoutingPolicy_route_out__Line4__set_community_3_0_community
             ()
             Bool)
(declare-fun Config_edge-11_CommunityList_list1__Line1__exact_community_2_1_action
             ()
             Bool)
(declare-fun Config_edge-11_CommunityList_list1__Line1__exact_community_2_1_2_1_community
             ()
             Bool)
(declare-fun Config_edge-11_CommunityList_list2__Line1__exact_community_5_1_action
             ()
             Bool)
(declare-fun Config_edge-11_CommunityList_list2__Line1__exact_community_5_1_5_1_community
             ()
             Bool)
(declare-fun Config_edge-11_RoutingPolicy_route_out__Line3__set_community_5_1_community
             ()
             Bool)
(declare-fun Config_edge-11_RoutingPolicy_route_out__Line4__set_community_2_1_community
             ()
             Bool)
(declare-fun Config_aggregation-16_CommunityList_list1__Line1__exact_community_1_3_action
             ()
             Bool)
(declare-fun Config_aggregation-16_CommunityList_list1__Line1__exact_community_1_3_1_3_community
             ()
             Bool)
(declare-fun Config_aggregation-16_CommunityList_list2__Line1__exact_community_4_3_action
             ()
             Bool)
(declare-fun Config_aggregation-16_CommunityList_list2__Line1__exact_community_4_3_4_3_community
             ()
             Bool)
(declare-fun Config_aggregation-16_RoutingPolicy_route_out__Line3__set_community_4_3_community
             ()
             Bool)
(declare-fun Config_aggregation-16_RoutingPolicy_route_out__Line4__set_community_1_3_community
             ()
             Bool)
(declare-fun Config_core-2_CommunityList_list1__Line1__exact_community_3_0_action
             ()
             Bool)
(declare-fun Config_core-2_CommunityList_list1__Line1__exact_community_3_0_3_0_community
             ()
             Bool)
(declare-fun Config_core-2_CommunityList_list2__Line1__exact_community_6_0_action
             ()
             Bool)
(declare-fun Config_core-2_CommunityList_list2__Line1__exact_community_6_0_6_0_community
             ()
             Bool)
(declare-fun Config_core-2_RoutingPolicy_route_out__Line3__set_community_6_0_community
             ()
             Bool)
(declare-fun Config_core-2_RoutingPolicy_route_out__Line4__set_community_3_0_community
             ()
             Bool)
(declare-fun Config_edge-14_CommunityList_list1__Line1__exact_community_2_2_action
             ()
             Bool)
(declare-fun Config_edge-14_CommunityList_list1__Line1__exact_community_2_2_2_2_community
             ()
             Bool)
(declare-fun Config_edge-14_CommunityList_list2__Line1__exact_community_5_2_action
             ()
             Bool)
(declare-fun Config_edge-14_CommunityList_list2__Line1__exact_community_5_2_5_2_community
             ()
             Bool)
(declare-fun Config_edge-14_RoutingPolicy_route_out__Line3__set_community_5_2_community
             ()
             Bool)
(declare-fun Config_edge-14_RoutingPolicy_route_out__Line4__set_community_2_2_community
             ()
             Bool)
(declare-fun Config_edge-19_CommunityList_list1__Line1__exact_community_2_3_action
             ()
             Bool)
(declare-fun Config_edge-19_CommunityList_list1__Line1__exact_community_2_3_2_3_community
             ()
             Bool)
(declare-fun Config_edge-19_CommunityList_list2__Line1__exact_community_5_3_action
             ()
             Bool)
(declare-fun Config_edge-19_CommunityList_list2__Line1__exact_community_5_3_5_3_community
             ()
             Bool)
(declare-fun Config_edge-19_RoutingPolicy_route_out__Line3__set_community_5_3_community
             ()
             Bool)
(declare-fun Config_edge-19_RoutingPolicy_route_out__Line4__set_community_2_3_community
             ()
             Bool)
(declare-fun Config_edge-6_CommunityList_list1__Line1__exact_community_2_0_action
             ()
             Bool)
(declare-fun Config_edge-6_CommunityList_list1__Line1__exact_community_2_0_2_0_community
             ()
             Bool)
(declare-fun Config_edge-6_CommunityList_list2__Line1__exact_community_5_0_action
             ()
             Bool)
(declare-fun Config_edge-6_CommunityList_list2__Line1__exact_community_5_0_5_0_community
             ()
             Bool)
(declare-fun Config_edge-6_RoutingPolicy_route_out__Line3__set_community_5_0_community
             ()
             Bool)
(declare-fun Config_edge-6_RoutingPolicy_route_out__Line4__set_community_2_0_community
             ()
             Bool)
(declare-fun Config_edge-7_CommunityList_list1__Line1__exact_community_2_0_action
             ()
             Bool)
(declare-fun Config_edge-7_CommunityList_list1__Line1__exact_community_2_0_2_0_community
             ()
             Bool)
(declare-fun Config_edge-7_CommunityList_list2__Line1__exact_community_5_0_action
             ()
             Bool)
(declare-fun Config_edge-7_CommunityList_list2__Line1__exact_community_5_0_5_0_community
             ()
             Bool)
(declare-fun Config_edge-7_RoutingPolicy_route_out__Line3__set_community_5_0_community
             ()
             Bool)
(declare-fun Config_edge-7_RoutingPolicy_route_out__Line4__set_community_2_0_community
             ()
             Bool)
(declare-fun Config_aggregation-5_CommunityList_list1__Line1__exact_community_1_0_action
             ()
             Bool)
(declare-fun Config_aggregation-5_CommunityList_list1__Line1__exact_community_1_0_1_0_community
             ()
             Bool)
(declare-fun Config_aggregation-5_CommunityList_list2__Line1__exact_community_4_0_action
             ()
             Bool)
(declare-fun Config_aggregation-5_CommunityList_list2__Line1__exact_community_4_0_4_0_community
             ()
             Bool)
(declare-fun Config_aggregation-5_RoutingPolicy_route_out__Line3__set_community_4_0_community
             ()
             Bool)
(declare-fun Config_aggregation-5_RoutingPolicy_route_out__Line4__set_community_1_0_community
             ()
             Bool)
(declare-fun Config_aggregation-4_CommunityList_list1__Line1__exact_community_1_0_action
             ()
             Bool)
(declare-fun Config_aggregation-4_CommunityList_list1__Line1__exact_community_1_0_1_0_community
             ()
             Bool)
(declare-fun Config_aggregation-4_CommunityList_list2__Line1__exact_community_4_0_action
             ()
             Bool)
(declare-fun Config_aggregation-4_CommunityList_list2__Line1__exact_community_4_0_4_0_community
             ()
             Bool)
(declare-fun Config_aggregation-4_RoutingPolicy_route_out__Line3__set_community_4_0_community
             ()
             Bool)
(declare-fun Config_aggregation-4_RoutingPolicy_route_out__Line4__set_community_1_0_community
             ()
             Bool)
(declare-fun Config_aggregation-9_CommunityList_list1__Line1__exact_community_1_1_action
             ()
             Bool)
(declare-fun Config_aggregation-9_CommunityList_list1__Line1__exact_community_1_1_1_1_community
             ()
             Bool)
(declare-fun Config_aggregation-9_CommunityList_list2__Line1__exact_community_4_1_action
             ()
             Bool)
(declare-fun Config_aggregation-9_CommunityList_list2__Line1__exact_community_4_1_4_1_community
             ()
             Bool)
(declare-fun Config_aggregation-9_RoutingPolicy_route_out__Line3__set_community_4_1_community
             ()
             Bool)
(declare-fun Config_aggregation-9_RoutingPolicy_route_out__Line4__set_community_1_1_community
             ()
             Bool)
(declare-fun Config_aggregation-8_CommunityList_list1__Line1__exact_community_1_1_action
             ()
             Bool)
(declare-fun Config_aggregation-8_CommunityList_list1__Line1__exact_community_1_1_1_1_community
             ()
             Bool)
(declare-fun Config_aggregation-8_CommunityList_list2__Line1__exact_community_4_1_action
             ()
             Bool)
(declare-fun Config_aggregation-8_CommunityList_list2__Line1__exact_community_4_1_4_1_community
             ()
             Bool)
(declare-fun Config_aggregation-8_RoutingPolicy_route_out__Line3__set_community_4_1_community
             ()
             Bool)
(declare-fun Config_aggregation-8_RoutingPolicy_route_out__Line4__set_community_1_1_community
             ()
             Bool)
(declare-fun Config_aggregation-13_CommunityList_list1__Line1__exact_community_1_2_action
             ()
             Bool)
(declare-fun Config_aggregation-13_CommunityList_list1__Line1__exact_community_1_2_1_2_community
             ()
             Bool)
(declare-fun Config_aggregation-13_CommunityList_list2__Line1__exact_community_4_2_action
             ()
             Bool)
(declare-fun Config_aggregation-13_CommunityList_list2__Line1__exact_community_4_2_4_2_community
             ()
             Bool)
(declare-fun Config_aggregation-13_RoutingPolicy_route_out__Line3__set_community_4_2_community
             ()
             Bool)
(declare-fun Config_aggregation-13_RoutingPolicy_route_out__Line4__set_community_1_2_community
             ()
             Bool)
(declare-fun Config_aggregation-12_CommunityList_list1__Line1__exact_community_1_2_action
             ()
             Bool)
(declare-fun Config_aggregation-12_CommunityList_list1__Line1__exact_community_1_2_1_2_community
             ()
             Bool)
(declare-fun Config_aggregation-12_CommunityList_list2__Line1__exact_community_4_2_action
             ()
             Bool)
(declare-fun Config_aggregation-12_CommunityList_list2__Line1__exact_community_4_2_4_2_community
             ()
             Bool)
(declare-fun Config_aggregation-12_RoutingPolicy_route_out__Line3__set_community_4_2_community
             ()
             Bool)
(declare-fun Config_aggregation-12_RoutingPolicy_route_out__Line4__set_community_1_2_community
             ()
             Bool)
(declare-fun Config_edge-10_CommunityList_list1__Line1__exact_community_2_1_action
             ()
             Bool)
(declare-fun Config_edge-10_CommunityList_list1__Line1__exact_community_2_1_2_1_community
             ()
             Bool)
(declare-fun Config_edge-10_CommunityList_list2__Line1__exact_community_5_1_action
             ()
             Bool)
(declare-fun Config_edge-10_CommunityList_list2__Line1__exact_community_5_1_5_1_community
             ()
             Bool)
(declare-fun Config_edge-10_RoutingPolicy_route_out__Line3__set_community_5_1_community
             ()
             Bool)
(declare-fun Config_edge-10_RoutingPolicy_route_out__Line4__set_community_2_1_community
             ()
             Bool)
(assert (= Config_edge-15_CommunityList_list1__Line1__exact_community_2_2_action true))
(assert (= Config_edge-15_CommunityList_list1__Line1__exact_community_2_2_2_2_community
   true))
(assert (= Config_edge-15_CommunityList_list2__Line1__exact_community_5_2_action true))
(assert (= Config_edge-15_CommunityList_list2__Line1__exact_community_5_2_5_2_community
   true))
(assert (= Config_edge-15_RoutingPolicy_route_out__Line3__set_community_5_2_community
   true))
(assert (= Config_edge-15_RoutingPolicy_route_out__Line4__set_community_2_2_community
   true))
(assert (= Config_core-1_CommunityList_list1__Line1__exact_community_3_0_action true))
(assert (= Config_core-1_CommunityList_list1__Line1__exact_community_3_0_3_0_community
   true))
(assert (= Config_core-1_CommunityList_list2__Line1__exact_community_6_0_action true))
(assert (= Config_core-1_CommunityList_list2__Line1__exact_community_6_0_6_0_community
   true))
(assert (= Config_core-1_RoutingPolicy_route_out__Line3__set_community_6_0_community
   true))
(assert (= Config_core-1_RoutingPolicy_route_out__Line4__set_community_3_0_community
   true))
(assert (= Config_core-0_CommunityList_list1__Line1__exact_community_3_0_action true))
(assert (= Config_core-0_CommunityList_list1__Line1__exact_community_3_0_3_0_community
   true))
(assert (= Config_core-0_CommunityList_list2__Line1__exact_community_6_0_action true))
(assert (= Config_core-0_CommunityList_list2__Line1__exact_community_6_0_6_0_community
   true))
(assert (= Config_core-0_RoutingPolicy_route_out__Line3__set_community_6_0_community
   true))
(assert (= Config_core-0_RoutingPolicy_route_out__Line4__set_community_3_0_community
   true))
(assert (= Config_edge-18_CommunityList_list1__Line1__exact_community_2_3_action true))
(assert (= Config_edge-18_CommunityList_list1__Line1__exact_community_2_3_2_3_community
   true))
(assert (= Config_edge-18_CommunityList_list2__Line1__exact_community_5_3_action true))
(assert (= Config_edge-18_CommunityList_list2__Line1__exact_community_5_3_5_3_community
   true))
(assert (= Config_edge-18_RoutingPolicy_route_out__Line3__set_community_5_3_community
   true))
(assert (= Config_edge-18_RoutingPolicy_route_out__Line4__set_community_2_3_community
   true))
(assert (= Config_aggregation-17_CommunityList_list1__Line1__exact_community_1_3_action
   true))
(assert (= Config_aggregation-17_CommunityList_list1__Line1__exact_community_1_3_1_3_community
   true))
(assert (= Config_aggregation-17_CommunityList_list2__Line1__exact_community_4_3_action
   true))
(assert (= Config_aggregation-17_CommunityList_list2__Line1__exact_community_4_3_4_3_community
   true))
(assert (= Config_aggregation-17_RoutingPolicy_route_out__Line3__set_community_4_3_community
   true))
(assert (= Config_aggregation-17_RoutingPolicy_route_out__Line4__set_community_1_3_community
   true))
(assert (= Config_core-3_CommunityList_list1__Line1__exact_community_3_0_action true))
(assert (= Config_core-3_CommunityList_list1__Line1__exact_community_3_0_3_0_community
   true))
(assert (= Config_core-3_CommunityList_list2__Line1__exact_community_6_0_action true))
(assert (= Config_core-3_CommunityList_list2__Line1__exact_community_6_0_6_0_community
   true))
(assert (= Config_core-3_RoutingPolicy_route_out__Line3__set_community_6_0_community
   true))
(assert (= Config_core-3_RoutingPolicy_route_out__Line4__set_community_3_0_community
   true))
(assert (= Config_edge-11_CommunityList_list1__Line1__exact_community_2_1_action true))
(assert (= Config_edge-11_CommunityList_list1__Line1__exact_community_2_1_2_1_community
   true))
(assert (= Config_edge-11_CommunityList_list2__Line1__exact_community_5_1_action true))
(assert (= Config_edge-11_CommunityList_list2__Line1__exact_community_5_1_5_1_community
   true))
(assert (= Config_edge-11_RoutingPolicy_route_out__Line3__set_community_5_1_community
   true))
(assert (= Config_edge-11_RoutingPolicy_route_out__Line4__set_community_2_1_community
   true))
(assert (= Config_aggregation-16_CommunityList_list1__Line1__exact_community_1_3_action
   true))
(assert (= Config_aggregation-16_CommunityList_list1__Line1__exact_community_1_3_1_3_community
   true))
(assert (= Config_aggregation-16_CommunityList_list2__Line1__exact_community_4_3_action
   true))
(assert (= Config_aggregation-16_CommunityList_list2__Line1__exact_community_4_3_4_3_community
   true))
(assert (= Config_aggregation-16_RoutingPolicy_route_out__Line3__set_community_4_3_community
   true))
(assert (= Config_aggregation-16_RoutingPolicy_route_out__Line4__set_community_1_3_community
   true))
(assert (= Config_core-2_CommunityList_list1__Line1__exact_community_3_0_action true))
(assert (= Config_core-2_CommunityList_list1__Line1__exact_community_3_0_3_0_community
   true))
(assert (= Config_core-2_CommunityList_list2__Line1__exact_community_6_0_action true))
(assert (= Config_core-2_CommunityList_list2__Line1__exact_community_6_0_6_0_community
   true))
(assert (= Config_core-2_RoutingPolicy_route_out__Line3__set_community_6_0_community
   true))
(assert (= Config_core-2_RoutingPolicy_route_out__Line4__set_community_3_0_community
   true))
(assert (= Config_edge-14_CommunityList_list1__Line1__exact_community_2_2_action true))
(assert (= Config_edge-14_CommunityList_list1__Line1__exact_community_2_2_2_2_community
   true))
(assert (= Config_edge-14_CommunityList_list2__Line1__exact_community_5_2_action true))
(assert (= Config_edge-14_CommunityList_list2__Line1__exact_community_5_2_5_2_community
   true))
(assert (= Config_edge-14_RoutingPolicy_route_out__Line3__set_community_5_2_community
   true))
(assert (= Config_edge-14_RoutingPolicy_route_out__Line4__set_community_2_2_community
   true))
(assert (= Config_edge-19_CommunityList_list1__Line1__exact_community_2_3_action true))
(assert (= Config_edge-19_CommunityList_list1__Line1__exact_community_2_3_2_3_community
   true))
(assert (= Config_edge-19_CommunityList_list2__Line1__exact_community_5_3_action true))
(assert (= Config_edge-19_CommunityList_list2__Line1__exact_community_5_3_5_3_community
   true))
(assert (= Config_edge-19_RoutingPolicy_route_out__Line3__set_community_5_3_community
   true))
(assert (= Config_edge-19_RoutingPolicy_route_out__Line4__set_community_2_3_community
   true))
(assert (= Config_edge-6_CommunityList_list1__Line1__exact_community_2_0_action true))
(assert (= Config_edge-6_CommunityList_list1__Line1__exact_community_2_0_2_0_community
   true))
(assert (= Config_edge-6_CommunityList_list2__Line1__exact_community_5_0_action true))
(assert (= Config_edge-6_CommunityList_list2__Line1__exact_community_5_0_5_0_community
   true))
(assert (= Config_edge-6_RoutingPolicy_route_out__Line3__set_community_5_0_community
   true))
(assert (= Config_edge-6_RoutingPolicy_route_out__Line4__set_community_2_0_community
   true))
(assert (= Config_edge-7_CommunityList_list1__Line1__exact_community_2_0_action true))
(assert (= Config_edge-7_CommunityList_list1__Line1__exact_community_2_0_2_0_community
   true))
(assert (= Config_edge-7_CommunityList_list2__Line1__exact_community_5_0_action true))
(assert (= Config_edge-7_CommunityList_list2__Line1__exact_community_5_0_5_0_community
   true))
(assert (= Config_edge-7_RoutingPolicy_route_out__Line3__set_community_5_0_community
   true))
(assert (= Config_edge-7_RoutingPolicy_route_out__Line4__set_community_2_0_community
   true))
(assert (= Config_aggregation-5_CommunityList_list1__Line1__exact_community_1_0_action
   true))
(assert (= Config_aggregation-5_CommunityList_list1__Line1__exact_community_1_0_1_0_community
   true))
(assert (= Config_aggregation-5_CommunityList_list2__Line1__exact_community_4_0_action
   true))
(assert (= Config_aggregation-5_CommunityList_list2__Line1__exact_community_4_0_4_0_community
   true))
(assert (= Config_aggregation-5_RoutingPolicy_route_out__Line3__set_community_4_0_community
   true))
(assert (= Config_aggregation-5_RoutingPolicy_route_out__Line4__set_community_1_0_community
   true))
(assert (= Config_aggregation-4_CommunityList_list1__Line1__exact_community_1_0_action
   true))
(assert (= Config_aggregation-4_CommunityList_list1__Line1__exact_community_1_0_1_0_community
   true))
(assert (= Config_aggregation-4_CommunityList_list2__Line1__exact_community_4_0_action
   true))
(assert (= Config_aggregation-4_CommunityList_list2__Line1__exact_community_4_0_4_0_community
   true))
(assert (= Config_aggregation-4_RoutingPolicy_route_out__Line3__set_community_4_0_community
   true))
(assert (= Config_aggregation-4_RoutingPolicy_route_out__Line4__set_community_1_0_community
   true))
(assert (= Config_aggregation-9_CommunityList_list1__Line1__exact_community_1_1_action
   true))
(assert (= Config_aggregation-9_CommunityList_list1__Line1__exact_community_1_1_1_1_community
   true))
(assert (= Config_aggregation-9_CommunityList_list2__Line1__exact_community_4_1_action
   true))
(assert (= Config_aggregation-9_CommunityList_list2__Line1__exact_community_4_1_4_1_community
   true))
(assert (= Config_aggregation-9_RoutingPolicy_route_out__Line3__set_community_4_1_community
   true))
(assert (= Config_aggregation-9_RoutingPolicy_route_out__Line4__set_community_1_1_community
   true))
(assert (= Config_aggregation-8_CommunityList_list1__Line1__exact_community_1_1_action
   true))
(assert (= Config_aggregation-8_CommunityList_list1__Line1__exact_community_1_1_1_1_community
   true))
(assert (= Config_aggregation-8_CommunityList_list2__Line1__exact_community_4_1_action
   true))
(assert (= Config_aggregation-8_CommunityList_list2__Line1__exact_community_4_1_4_1_community
   true))
(assert (= Config_aggregation-8_RoutingPolicy_route_out__Line3__set_community_4_1_community
   true))
(assert (= Config_aggregation-8_RoutingPolicy_route_out__Line4__set_community_1_1_community
   true))
(assert (= Config_aggregation-13_CommunityList_list1__Line1__exact_community_1_2_action
   true))
(assert (= Config_aggregation-13_CommunityList_list1__Line1__exact_community_1_2_1_2_community
   true))
(assert (= Config_aggregation-13_CommunityList_list2__Line1__exact_community_4_2_action
   true))
(assert (= Config_aggregation-13_CommunityList_list2__Line1__exact_community_4_2_4_2_community
   true))
(assert (= Config_aggregation-13_RoutingPolicy_route_out__Line3__set_community_4_2_community
   true))
(assert (= Config_aggregation-13_RoutingPolicy_route_out__Line4__set_community_1_2_community
   true))
(assert (= Config_aggregation-12_CommunityList_list1__Line1__exact_community_1_2_action
   true))
(assert (= Config_aggregation-12_CommunityList_list1__Line1__exact_community_1_2_1_2_community
   true))
(assert (= Config_aggregation-12_CommunityList_list2__Line1__exact_community_4_2_action
   true))
(assert (= Config_aggregation-12_CommunityList_list2__Line1__exact_community_4_2_4_2_community
   true))
(assert (= Config_aggregation-12_RoutingPolicy_route_out__Line3__set_community_4_2_community
   true))
(assert (= Config_aggregation-12_RoutingPolicy_route_out__Line4__set_community_1_2_community
   true))
(assert (= Config_edge-10_CommunityList_list1__Line1__exact_community_2_1_action true))
(assert (= Config_edge-10_CommunityList_list1__Line1__exact_community_2_1_2_1_community
   true))
(assert (= Config_edge-10_CommunityList_list2__Line1__exact_community_5_1_action true))
(assert (= Config_edge-10_CommunityList_list2__Line1__exact_community_5_1_5_1_community
   true))
(assert (= Config_edge-10_RoutingPolicy_route_out__Line3__set_community_5_1_community
   true))
(assert (= Config_edge-10_RoutingPolicy_route_out__Line4__set_community_2_1_community
   true))

